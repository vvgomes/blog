# Lunch Time

This application is intended to help your team to choose democratically where to have lunch. The idea is that every day the app will present a poll with restaurants nearby and users can give'm votes. The most voted restaurant goes to the top and should be the lunch destination for the day. Here is a screenshot:

![screenshot.png](https://bitbucket.org/repo/7EEGdp5/images/4077987249-screenshot.png)

This first version of the app contains seed data from top rated restaurants in the Sydney central area. Data was obtained through the Yelp public API (https://www.yelp.com/developers/).

## Running

- Ensure a recent Node version.
- Navigate to the client directory.
- Run `$ npm install`
- Navigate to the server directory.
- Run `$ npm install`
- Start the server with `$ npm start`
- Seed data with `$ npm run seed`
- Using a browser, go to http://localhost:3000
- In order to login use one of the credentials in the **server/data/users.json** file.

## Development Notes

The application has two main components: the server and the web client. They exchange information using HTTP and ensure authentication using the Basic HTTP strategy. There is no data storage backing up the voting part of the app (votes and winners stay in-memory) but there is a static list of restaurants and users.

### The Server

The server side app contains all the relevant business logic. It serves an HTTP API that follows a *Action Sourcing* style. It exposes basically two endpoints: one to retrieve the app current *state* and another one to allow clients sending *actions*. The workflow looks like this:

**Start a new poll**

- Request: `POST /actions`
- Payload: `{ "type": "startNewPoll" }`
- Status: `202`
- Body: `{ "type": "startNewPoll" }`

**Retrieve current poll**

- Request: `GET /poll`
- Status: `200`
- Body: `{ "date": "2017-05-04", "restaurants": [ { ... } ] }`

**Vote**

- Request: `POST /actions`
- Payload: `{ "type": "vote", "date": "2017-05-04", "restaurant": { "id": "42"} }`
- Status: `202`
- Body: `{ "type": "vote", "date": "2017-05-04", "restaurant": { "id": "42"} }`

* All requests require the user to be properly authenticated.

The server app is a Javascript application and it was developed using the [Redux](http://redux.js.org/) library which implements this action-driven architectural style. There are a few important modules that worth being mentioned:

- **Store** => Represents an aggregate of actions. It holds the current state and dispatches incoming actions.
- **Action Handlers** => Functions responsible to transform the current state into a next state based on an action type.
- **Action Validators** => Functions responsible to ensure an action is valid given its data and the current state.
- **API** => An [Express](http://expressjs.com/) router to handle the HTTP requests and call the store.
- **Server** => An [Express](http://expressjs.com/) web app which acts like the entry point. It connects the API, the authentication middleware, and the static content together.

**Some interesting details**

- For the basic auth middleware I used [Passport](http://passportjs.org/) library which integrates well with Express.
- To implement the action validation logic I used [Predicado](https://www.npmjs.com/package/predicado) which is a library I developed myself last year as an enhancement to the [data.validation](https://www.npmjs.com/package/data.validation) module from [Folktale](http://folktalejs.org/).
- I use [Ramda](http://ramdajs.com/) quite intensively as you will notice in the code. Ramda provides really good functional programming support specially when it comes to ensuring immutability, using point-free compositions, and favoring currying.
- Pretty much everything is covered by unit tests, but I also added functional tests in the API level. For that we used a pretty much [Mocha](http://mochajs.org/) and [Supertest](https://github.com/visionmedia/supertest).
 
### The Client

The client side is also based on Redux with [React](https://facebook.github.io/react/) for the UI components. Since all the relevant logic lives in the server, there only a few things the client is responsible to, including refreshing the current poll state, sending votes, and rendering components accordingly. Some interesting modules in the client app:

- **Store** => Holds the client side state of the app. The only action we can dispatch directly to it is `refreshPoll`.
- **API Client** => Module responsible for communicating with the API. It handles authentication, responses, and builds remote actions.
- **Action Dispatchers** => Responsible for handling the front-end intents to interact with the API. It talks to the API client and eventually talks to the store to dispatch actions.
- **UI Components** => React "pure" components. Responsible for building the poll UI including the list of restaurants, its details, votes, etc.

Another thing worth to mention in the client app is that besides Mocha I also used [Enzyme](https://github.com/airbnb/enzyme) and [JSDom](https://github.com/tmpvar/jsdom) so that the tests are fully headless and lightweight. Besides that, like in the server, I also use a lot of Ramda and its functional style everywhere in the code.

### Style

Given the limited time, I decided not to write my own style code to make the app look a bit better. Instead I used [Materialize](http://materializecss.com/).

---
