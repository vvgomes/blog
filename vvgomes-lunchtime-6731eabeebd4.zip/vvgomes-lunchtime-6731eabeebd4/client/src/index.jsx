import React from "react";
import { render } from "react-dom";
import { connect, Provider } from "react-redux";
import createStore from "./store"
import createActionDispatchers from "./action.dispatchers";
import App from "./components/app";
import { identity } from "ramda";

const store = createStore();
const ConnectedApp = connect(
  identity,
  createActionDispatchers
)(App);

// initial data load before render
createActionDispatchers(store.dispatch).reloadPoll();

render(
  <Provider store={store}>
    <ConnectedApp />
  </Provider>,
  document.getElementById("app")
);


