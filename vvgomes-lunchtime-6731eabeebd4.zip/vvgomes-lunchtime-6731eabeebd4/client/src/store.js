import { createStore } from "redux";
import Maybe from "data.maybe";
import { apply, flip } from "ramda";
import * as defaultActionHandlers from "./action.handlers";

const defineReducer = actionHandlers =>
  (state, action) => 
    Maybe
      .fromNullable(actionHandlers[action.type])
      .map(flip(apply)([state, action]))
      .getOrElse(state);

export default (actionHandlers = defaultActionHandlers) =>
  createStore(defineReducer(actionHandlers), {});

