export const refreshPoll = (state, action) => ({
  date: action.date,
  restaurants: action.restaurants,
  user: action.user
});

