import createApiClient from "./api.client";
import * as creators from "./action.creators";
import { compose, prop } from "ramda";

const createActionDispatchers = (
  dispatch,
  apiClient = createApiClient()
) => {
  const reloadPoll = () =>
    apiClient
      .fetchPoll()
      .then(creators.refreshPoll)
      .then(dispatch);

  const sendVote = (restaurant, date) =>
    apiClient
      .vote(restaurant, date)
      .then(reloadPoll);

  return { reloadPoll, sendVote };
}

export default createActionDispatchers;
