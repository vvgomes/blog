export const refreshPoll = ({ date, restaurants, user }) => (
  { type: "refreshPoll", date, restaurants, user }
);
