import defaultFetch from "isomorphic-fetch";
import defaultAuth from "./auth";
import { merge, pick } from "ramda";

const createApiClient = (
  fetch = defaultFetch,
  auth = defaultAuth
) => {
  const buildHeaders = () => ({
    "Accept": "application/json",
    "Content-Type": "application/json",
    "Authorization": auth()
  });

  const performRequest = (path, opts = {}) =>
    fetch(path, merge(opts, { headers: buildHeaders() }))
      .then(res => res.json());

  const fetchPoll = () =>
    performRequest("/api/poll");

  const vote = (restaurant, date) =>
    performRequest("/api/actions", {
      method: "POST",
      body: JSON.stringify({
        type: "vote",
        restaurant: pick(["id"], restaurant),
        date
      })  
    });

  return { fetchPoll, vote };
};

export default createApiClient;

