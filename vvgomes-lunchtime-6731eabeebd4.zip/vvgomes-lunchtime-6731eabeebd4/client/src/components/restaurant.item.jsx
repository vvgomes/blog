import React from "react";
import { length, contains, path } from "ramda";

const RestaurantItem = (sendVote, date, user, restaurant) => {
  const voteCount = length(restaurant.votes);
  const voted = contains(user, restaurant.votes);
  const text = voted ? "Voted" : "Vote";
  const icon = voted ? "done" : "";
  const countText = `${voteCount} vote${ voteCount == 1 ? "" : "s" }`;
  const clickHandler = () => (voted || sendVote(restaurant, date));

  return (
    <li key={restaurant.id} className="restaurant-item card-panel">
      <h4 className="restaurant-name">{restaurant.name}</h4>
      <ul className="collection">
        <li className="collection-item">{path(["categories", 0, "title"], restaurant)}</li>
        <li className="collection-item">Rating: {restaurant.rating}</li>
        <li className="collection-item">Price: {restaurant.price}</li>
        <li className="collection-item"><a href={restaurant.url}>See on Yelp</a></li>
      </ul>
      <span className="restaurant-vote-count badge">{countText}</span>
      <button className="send-vote waves-light btn" disabled={voted} onClick={clickHandler}>
        <i className="material-icons right">{icon}</i>
        <span>{text}</span>
      </button>
    </li>
  );
}

export default RestaurantItem;
