import React from "react";
import RestaurantList from "./restaurant.list";
import { compose } from "ramda";

const App = compose(
  content => (<main className="container">{content}</main>),
  RestaurantList
);

export default App;
