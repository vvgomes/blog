import React from "react";
import RestaurantItem from "./restaurant.item";
import { compose, map, curry, sortBy, reverse, length, prop } from "ramda";

const renderItems = ({ restaurants, date, user, sendVote }) => compose(
  map(restaurant => RestaurantItem(sendVote, date, user, restaurant)),
  reverse, sortBy(compose(length, prop("votes")))
)(restaurants || []);

const RestaurantList = compose(
  items => (<ul className="restaurant-list">{items}</ul>),
  renderItems);
  
export default RestaurantList;
