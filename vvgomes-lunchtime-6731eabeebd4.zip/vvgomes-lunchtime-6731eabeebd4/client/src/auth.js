import { pipe, split, map, trim, find, test, replace } from "ramda";
import Maybe from "data.maybe";

const findAuthCookie = pipe(
  split(";"),
  map(trim),
  find(test(/^auth=/)),
  Maybe.fromNullable,
  map(replace(/^auth=/, ""))
);

const authorization = (cookies = document.cookie) =>
  findAuthCookie(cookies).getOrElse("");

export default authorization;
