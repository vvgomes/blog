import { refreshPoll } from "../src/action.handlers";
import { expect } from "chai";

describe("actionHandlers{}", () => {

  describe("refreshPoll()", () => {
    it("populates the restaurant list", () => {
      const user = "vinicius";
      const date = "2017-04-30";
      const restaurants = [
        { id: "42", name: "Chipotle", votes: [] },
        { id: "43", name: "Shake Shack", votes: [] },
        { id: "44", name: "Halal Guys", votes: [] }
      ]; 

      const state = {};
      const action = { type: "refreshPoll", date, restaurants, user };
      const newState = refreshPoll(state, action);

      expect(newState).deep.eq({ date, restaurants, user });
    });
  });
});

