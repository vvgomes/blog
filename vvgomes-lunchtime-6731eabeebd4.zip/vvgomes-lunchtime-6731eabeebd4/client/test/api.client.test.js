import createApiClient from "../src/api.client";
import { expect } from "chai";
import { stub, match } from "sinon";

describe("apiClient{}", () => {

  describe("fetchPoll()", () => {
    it("retrieves the poll state from the server", () => {
      const user = "vinicius";
      const date = "2017-04-30";
      const restaurants = [
        { id: "42", name: "Chipotle", votes: [] },
        { id: "43", name: "Shake Shack", votes: [] },
        { id: "44", name: "Halal Guys", votes: [] }
      ]; 

      const fakeFetch = stub()
        .withArgs("/api/poll")
        .returns(buildResponse(200, { date, restaurants, user }))

      const client = createApiClient(fakeFetch);

      client.fetchPoll().then(state => {
        expect(state).deep.eq({ date, restaurants, user });
      });
    });
  });

  describe("vote()", () => {
    it("sends a vote remote action", () => {
      const expectedAction = {
        type: "vote",
        date: "2017-04-30",
        restaurant: { id: "42" } 
      };
  
      const fakeFetch = stub()
        .withArgs("/api/actions", buildPayload(expectedAction))
        .returns(buildResponse(202, expectedAction))

      const client = createApiClient(fakeFetch);
      const restaurant = { id: "42", name: "Chipotle" };

      client.vote(restaurant, "2017-04-30").then(actualAction => {
        expect(actualAction).deep.eq(expectedAction);
      });
    });
  });

  function buildResponse(status, data) {
    return Promise.resolve({
      status, json: () => Promise.resolve(data)
    }); 
  }

  function buildPayload(data) {
    return match
      .has("method", "POST")
      .and(match.has("headers"))
      .and(match.has("body", JSON.stringify(data)));
  }
});
