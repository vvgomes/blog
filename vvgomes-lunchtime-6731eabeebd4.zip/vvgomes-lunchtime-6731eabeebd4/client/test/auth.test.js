import auth from "../src/auth";
import { expect } from "chai";

describe("auth()", () => {
  it("returns auth value from auth cookie", () => {
    const cookies = "auth=Basic dmluaWNpdXM6Y3VwY2FrZQ==";
    expect(auth(cookies)).eq("Basic dmluaWNpdXM6Y3VwY2FrZQ==");
  });

  it("returns auth value from auth cookie when there are many cookies", () => {
    const cookies = "_ga=GA1.2.348556171.1459218114; auth=Basic dmluaWNpdXM6Y3VwY2FrZQ==; tz=America%2FNew_York";
    expect(auth(cookies)).eq("Basic dmluaWNpdXM6Y3VwY2FrZQ==");
  });

  it("returns empty when there is no auth cookie", () => {
    const cookies = "_ga=GA1.2.348556171.1459218114; tz=America%2FNew_York";
    expect(auth(cookies)).empty;
  });

  it("returns empty when there are no cookies", () => {
    expect(auth("")).empty;
  });
});
