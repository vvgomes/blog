import createStore from "../src/store";
import { expect } from "chai";
import { always } from "ramda";

describe("store{}", () => {
  let store;
  const fakeHandlers = { arbitrary: always("arbitrary") };

  beforeEach(() => {
    store = createStore(fakeHandlers);
  });

  it("has an initial state", () => {
    expect(store.getState()).deep.eq({}); 
  });

  it("dispatches known actions", () => {
    store.dispatch({ type: "arbitrary" });
    expect(store.getState()).eq("arbitrary");
  });

  it("bypasses unknown actions", () => {
    store.dispatch({ type: "unknown" });
    expect(store.getState()).deep.eq({});
  });
});

