import React from "react";
import RestaurantItem from "../../src/components/restaurant.item";
import { shallow } from "enzyme";
import { expect } from "chai";
import { spy, match } from "sinon";

describe("RestaurantItem", () => {
  const sendVote = spy();
  const date = "2017-04-30";
  const user = "vinicius";

  beforeEach(() => {
    sendVote.reset();
  })

  describe("before vote", () => {
    const restaurant = {
      id: "42",
      name: "Chipotle",
      votes: [ "juliano", "guilherme" ]
    };

    const item = shallow(RestaurantItem(sendVote, date, user, restaurant));

    it("renders as a list item element", () => {
      expect(item.name()).eq("li");
    });

    it("has a key property", () => {
      expect(item.key()).eq("42");
    });

    it("renders restaurant name", () => {
      expect(item.find(".restaurant-name").text()).eq("Chipotle");
    });

    it("renders restaurant vote count", () => {
      expect(item.find(".restaurant-vote-count").text()).eq("2 votes");
    });

    it("renders vote button", () => {
      const button = item.find(".send-vote");
      expect(button.name()).eq("button");
      expect(button.text()).eq("Vote");
      expect(button.prop("disabled")).not.ok;
    });

    it("triggers sendVote() on click", () => {
      item.find(".send-vote").simulate("click");
      expect(sendVote.calledWith(
        match.has("id", "42"),
        match("2017-04-30")
      )).ok;
    });
  });

  describe("after vote", () => {
    const restaurant = {
      id: "42",
      name: "Chipotle",
      votes: [ "juliano", "guilherme", "vinicius" ]
    };

    const item = shallow(RestaurantItem(sendVote, date, user, restaurant));

    it("changes vote button text", () => {
      const button = item.find(".send-vote");
      expect(button.text()).match(/Voted/);
    });

    it("disables click handler", () => {
      item.find(".send-vote").simulate("click");
      expect(sendVote.notCalled).ok;
    });

    it("disables vote button", () => {
      const button = item.find(".send-vote");
      expect(button.prop("disabled")).ok;
    });
  });
});
