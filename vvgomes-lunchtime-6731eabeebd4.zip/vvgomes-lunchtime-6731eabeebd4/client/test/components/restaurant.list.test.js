import React from "react";
import RestaurantList from "../../src/components/restaurant.list";
import { shallow } from "enzyme";
import { expect } from "chai";
import { identity } from "ramda";

describe("RestaurantList", () => {
  const sendVote = identity;
  const date = "2017-04-30";
  const user = "vinicius";
  const restaurants = [
    { id: "42", name: "Chipotle", votes: [ "alabe" ] },
    { id: "43", name: "Shake Shack", votes: [] },
    { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
  ]; 

  const list = shallow(RestaurantList({ restaurants, date, user, sendVote }));

  it("renders an ordered list element", () => {
    expect(list.name()).eq("ul");
  });

  it("renders a list item for each restaurant", () => {
    expect(list.find("li.restaurant-item")).lengthOf(3);
  });

  it("sort restaurants by vote count desc", () => {
    expect(list.find(".restaurant-item").at(0).key()).eq("44");
    expect(list.find(".restaurant-item").at(1).key()).eq("42");
    expect(list.find(".restaurant-item").at(2).key()).eq("43");
  });
});


