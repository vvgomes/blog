import React from "react";
import App from "../../src/components/app";
import { shallow } from "enzyme";
import { expect } from "chai";
import { identity } from "ramda";

describe("App", () => {
  it("renders the restaurant list", () => {
    const user = "vinicius";
    const date = "2017-04-30";
    const app = shallow(App({ date, restaurants, user }));
    const restaurants = [
      { id: "42", name: "Chipotle", votes: [] },
      { id: "43", name: "Shake Shack", votes: [] },
      { id: "44", name: "Halal Guys", votes: [] }
    ]; 
    expect(app.find(".restaurant-list").exists()).ok;
  });
});
