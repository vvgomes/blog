import createActionDispatchers from "../src/action.dispatchers";
import { expect } from "chai";
import { stub } from "sinon";
import { identity, head } from "ramda";

describe("actionDispatchers{}", () => {
  let dispatchers;

  const dispatch = identity;
  const apiClient = { fetchPoll: stub(), vote: stub() };

  const user = "vinicius";
  const date = "2017-04-30";
  const restaurants = [
    { id: "42", name: "Chipotle", votes: [] },
    { id: "43", name: "Shake Shack", votes: [] },
    { id: "44", name: "Halal Guys", votes: [] }
  ]; 

  beforeEach(() => {
    dispatchers = createActionDispatchers(dispatch, apiClient);
  });
  
  describe("reloadPoll()", () => {
    it("dispatches refreshPoll action after fetching poll", () => {
      apiClient.fetchPoll.returns(Promise.resolve({ date, restaurants, user }));

      return dispatchers.reloadPoll().then(action => {
        expect(action).deep.eq({ type: "refreshPoll", restaurants, date, user });
      });
    });
  });
  
  describe("vote", () => {
    it("dispatches vote action", () => {
      const chipotle = head(restaurants);

      apiClient.vote.withArgs(chipotle, date).returns(Promise.resolve({}));
      apiClient.fetchPoll.returns(Promise.resolve({ date, restaurants, user }));

      return dispatchers.sendVote(chipotle, date).then(action => {
        expect(action).deep.eq({ type: "refreshPoll", restaurants, date, user });
      });
    }); 
  });
});
