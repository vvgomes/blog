import { startNewPoll, vote } from "../lib/action.handlers";
import { expect } from "chai";
import moment from "moment";

describe("actionHandlers{}", () => {

  describe("startNewPoll()", () => {
    const fixedMoment = () =>
      moment("2017-04-30");

    const restaurants = [
      { id: "42", name: "Chipotle" },
      { id: "43", name: "Shake Shack" },
      { id: "44", name: "Halal Guys" }
    ]; 

    it("starts a new poll for the current date when there are no previous polls", () => {
      const state = {};
      const action = { type: "startNewPoll" };
      const newState = startNewPoll(state, action, fixedMoment, restaurants);

      expect(newState).deep.eq({
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [] }
        ],
        winners: {}
      });
    });

    it("starts a new poll for the next day after the current poll without the winner", () => {
      const state = {
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      };

      const action = { type: "startNewPoll" };
      const newState = startNewPoll(state, action, fixedMoment, restaurants);

      expect(newState).deep.eq({
        date: "2017-05-01",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [] },
          { id: "43", name: "Shake Shack", votes: [] }
        ],
        winners: { "2017-04-30": "44" }
      });
    });

    it("starts a new poll without all winners this week", () => {
      const state = {
        date: "2017-05-02",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ],
        winners: {
          "2017-04-29": "42",
          "2017-04-30": "43" 
        }
      };

      const action = { type: "startNewPoll" };
      const newState = startNewPoll(state, action, moment, restaurants);

      expect(newState).deep.eq({
        date: "2017-05-03",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [] }
        ],
        winners: {
          "2017-04-30": "43",
          "2017-05-02": "44"
        }
      });
    });
  });

  describe("vote()", () => {
    it("adds a vote to a restaurant in the current poll", () => {
      const state = {
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      };

      const date = "2017-04-30";
      const user = "vinicius";
      const restaurant = { id: "43" };
      const action = { type: "vote", date, user, restaurant };
      const newState = vote(state, action);

      expect(newState).deep.eq({
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [ "vinicius" ] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      });
    });

    it("can't vote more than once", () => {
      const state = {
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [ "vinicius" ] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      };

      const date = "2017-04-30";
      const user = "vinicius";
      const restaurant = { id: "43" };
      const action = { type: "vote", date, user, restaurant };
      const newState = vote(state, action);

      expect(newState).deep.eq({
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [ "vinicius" ] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      });
    });

    it("changes vote", () => {
      const state = {
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [ "vinicius" ] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      };

      const date = "2017-04-30";
      const user = "vinicius";
      const restaurant = { id: "44" };
      const action = { type: "vote", date, user, restaurant };
      const newState = vote(state, action);

      expect(newState).deep.eq({
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme", "vinicius" ] }
        ]
      });
    });
  });
});
