import createApi from "../lib/api";
import createStore from "../lib/store";
import express from "express";
import request from "supertest";
import moment from "moment";
import { expect } from "chai";

describe("api", () => {
  const store = createStore();
  const api = createApi(store);
  const server = express().use(api);

  let pollDate;
  let firstRestaurant;

  store.subscribe(() => {
    pollDate = store.getState().date;
    firstRestaurant = store.getState().restaurants[0];
  });

  beforeEach(() => {
    store.dispatch({ type: "startNewPoll" });
  });

  describe("GET /poll", () => {
    it("responds with the current poll", () => {
      return request(server)
        .get("/poll")
        .set("Accept", "apilication/json")
        .expect("Content-Type", /json/)
        .expect(200)
        .then(res => {
          expect(res.body.date).eq(pollDate);          
          expect(res.body.restaurants).lengthOf(10);
        });
    });
  });

  describe("POST /actions", () => {
    it("responds with the successful action", () => {
      const action = {
        type: "vote",
        date: pollDate,
        user: "vinicius",
        restaurant: { id: firstRestaurant.id }
      };

      return request(server)
        .post("/actions")
        .send(action)
        .set("Accept", "apilication/json")
        .expect("Content-Type", /json/)
        .expect(202, { action });
    });

    it("responds with bad request when action is not accepted", () => {
      const action = {
        type: "vote",
        date: pollDate,
        user: "vinicius",
        restaurant: { id: "invalid" }
      };

      return request(server)
        .post("/actions")
        .send(action)
        .set("Accept", "apilication/json")
        .expect("Content-Type", /json/)
        .expect(400, { errors: ["Restaurant not found."] });
    });
  });
});

