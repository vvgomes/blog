import { startNewPoll, vote } from "../lib/action.validators";
import { expect } from "chai";
import Validation from "data.validation";

const Success = Validation.Success;
const Failure = Validation.Failure;

describe("actionValidators{}", () => {

  describe("startNewPoll()", () => {
    it("doesn't have any validations", () => {
      const state = {};
      const action = { type: "startNewPoll" };
      const result = startNewPoll(state, action);
      expect(result).deep.eq(Success(action));
    });
  });

  describe("vote()", () => {
    it("results in success when there are no violations", () => {
      const state = {
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      };

      const date = "2017-04-30";
      const user = "vinicius";
      const restaurant = { id: "43" };
      const action = { type: "vote", date, user, restaurant };
      const result = vote(state, action);

      expect(result).deep.eq(Success(action));
    });

    it("fails when vote date is invalid", () => {
      const state = {
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      };

      const date = "2017-04-29";
      const user = "vinicius";
      const restaurant = { id: "43" };
      const action = { type: "vote", date, user, restaurant };
      const result = vote(state, action);

      expect(result).deep.eq(Failure(["Invalid date."]));
    });

    it("fails when restaurant is not found in the poll", () => {
      const state = {
        date: "2017-04-30",
        restaurants: [
          { id: "42", name: "Chipotle", votes: [ "alabe" ] },
          { id: "43", name: "Shake Shack", votes: [] },
          { id: "44", name: "Halal Guys", votes: [ "juliano", "guilherme" ] }
        ]
      };

      const date = "2017-04-30";
      const user = "vinicius";
      const restaurant = { id: "45" };
      const action = { type: "vote", date, user, restaurant };
      const result = vote(state, action);

      expect(result).deep.eq(Failure(["Restaurant not found."]));
    });
  });
});

