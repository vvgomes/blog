import createStore from "../lib/store";
import { expect } from "chai";
import { always } from "ramda";
import Validation from "data.validation";
const Success = Validation.Success;

describe("store{}", () => {
  let store;

  const fakeHandlers = { arbitrary: always("arbitrary") };
  const fakeValidators = { arbitrary: always(Success({ type: "arbitrary" })) };

  beforeEach(() => store = createStore(fakeHandlers, fakeValidators));

  it("has an initial state", () => {
    expect(store.getState()).deep.eq({}); 
  });

  it("dispatches known actions", () => {
    const result = store.dispatch({ type: "arbitrary" });
    expect(result).deep.eq(Success({ type: "arbitrary" }));
    expect(store.getState()).eq("arbitrary");
  });

  it("bypasses unknown actions", () => {
    const result = store.dispatch({ type: "unknown" });
    expect(result).deep.eq(Success({ type: "unknown" }));
    expect(store.getState()).deep.eq({});
  });
});

