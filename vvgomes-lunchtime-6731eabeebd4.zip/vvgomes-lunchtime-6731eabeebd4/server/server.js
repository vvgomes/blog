import path from "path";
import express from "express";
import createApi from "./lib/api";
import { authenticate, setAuthCookie } from "./lib/auth";

express()
  .use(authenticate)
  .use(setAuthCookie)
  .use("/api", createApi())
  .use("/", express.static(path.join(__dirname, "assets")))
  .listen(3000, () => console.log("Server listening at http://localhost:3000"));

