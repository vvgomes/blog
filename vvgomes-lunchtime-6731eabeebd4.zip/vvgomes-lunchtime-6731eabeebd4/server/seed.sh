curl http://vinicius:cupcake@localhost:3000/api/actions \
  --data '{"type": "startNewPoll"}' \
  -H 'Content-Type:application/json'

